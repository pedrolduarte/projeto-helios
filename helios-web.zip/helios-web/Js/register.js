document.addEventListener("DOMContentLoaded", () => {
    const nextBtn = document.getElementById("nextStep");
    const step1 = document.getElementById("step1");
    const step2 = document.getElementById("step2");
  
    nextBtn.addEventListener("click", () => {
      const nome = document.getElementById("nome").value.trim();
      const email = document.getElementById("email").value.trim();
      const senha = document.getElementById("senha").value.trim();
  
      if (nome && email && senha) {
        step1.classList.add("hidden");
        step2.classList.remove("hidden");
      } else {
        alert("Por favor, preencha todos os campos antes de prosseguir.");
      }
    });
  });
  